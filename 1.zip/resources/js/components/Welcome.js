import React from 'react'

export default function Welcome() {
    return (

        <div className="text-white d-flex align-items-center justify-content-center h-100" >
            <div className="container text-center">
                <h1 className="display-4">Welcome To MyChatApp</h1>
                <p className="lead">Developed By Mizan Rifat</p>
            </div>
        </div>


    )
}

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" />


        <!-- Styles -->
        
    </head>
    <body>
        <div class="flex-center position-ref full-height">
                sdfsdfg
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\laravelAuth\resources\views/welcome.blade.php ENDPATH**/ ?>
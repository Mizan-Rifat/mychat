import React, { useEffect, useState } from 'react'
import axios from 'axios'

export default function Test() {

  const [data, setData] = useState([]);

  useEffect(() => {
    axios.get('https://demo.bagisto.com/bagisto-common/api/categories?pagination=0')
      .then(response => {
        // console.log(response)
        setData(response.data.data)
      })
      
  }, [])

  useEffect(() => {
    if (data.length > 0) {
      axios.post('/api/test', data)
        .then(response => {
          console.log(response)
        })
    }

  }, [data])


  return (
    <div>

    </div>
  )
}
